# Responsive Admin Dashboard

## [Watch it on YouTube](https://youtu.be/MRiZpwdy1CM)


Responsive Admin Dashboard UI using flutter,This project consist of responsive admin panel which can be run in desktop, tablet and mobile.

### :heart: Found this project useful?

If you found this project useful, then please consider giving it a :star: on Github and follow me on GitHub.

<a href="https://www.buymeacoffee.com/iamsayuj"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" height="60"></a>

### Responsive Admin Dashboard

![App UI](/adminpromo.gif)
![App UI](/scrvideo.gif)
![App UI](/thumb.png)
