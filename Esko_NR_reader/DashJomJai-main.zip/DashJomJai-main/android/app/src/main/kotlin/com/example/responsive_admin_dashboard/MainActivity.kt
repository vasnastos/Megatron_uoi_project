package com.example.responsive_admin_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
